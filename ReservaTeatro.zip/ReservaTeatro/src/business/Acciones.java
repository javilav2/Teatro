
package business;

import data.*;

public class Acciones {
    public void reservar(Dia dia,Usuario usuario){
        
    }
    
    public String consultarReserva(){
        return"";   
    }
    
    public void cambiarReserva(){
        
    }
    
    public void eliminarReserva(){
        
    }
    
    //public String buscarSillaDisponible(Pelicula ){
        
    //}
}
